#! /usr/bin/env python3
# -*- Coding:utf-8 -*-
"""
Only funny Appliacation can be here,
etc libary module file should be etc folder
"""
