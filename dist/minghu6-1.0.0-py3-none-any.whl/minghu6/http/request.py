# -*- Coding:utf-8 -*-
#!/usr/bin/env python3

"""

"""

headers={'User-Agent':('Mozilla/5.0(Windows NT 6.3)'
                       'AppleWebKit/537.36 (KHTML,like Gecko)'
                       'Chrome/39.0.2171.95'
                       'Safari/537.36'),
         'Accept':('text/html,application/xhtml+xml,'
                   'application/xml;'
                   'q=0.9,image/webp,*/*;q=0.8')}
