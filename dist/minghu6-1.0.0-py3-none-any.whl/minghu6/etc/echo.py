print('hi') 
